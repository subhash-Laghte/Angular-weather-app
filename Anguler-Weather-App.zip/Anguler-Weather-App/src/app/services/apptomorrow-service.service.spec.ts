import { TestBed } from '@angular/core/testing';

import { ApptomorrowServiceService } from './apptomorrow-service.service';

describe('ApptomorrowServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ApptomorrowServiceService = TestBed.get(ApptomorrowServiceService);
    expect(service).toBeTruthy();
  });
});
