import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class ApptomorrowServiceService {

  constructor(private httpclient: HttpClient) {}

  getapitomorrow(longitude,langitude,cityN) : Observable<any> {
    //return this.httpclient.get("https://api.tomorrow.io/v4/locations?apikey=sjnGSi0wgWO9fL1WC0rfNLuPN3RYsdHN");
 //   return this.httpclient.get("https://api.tomorrow.io/v4/timelines?location=-73.98529171943665,40.75872069597532&fields=temperature&timesteps=1h&units=metric&apikey=sjnGSi0wgWO9fL1WC0rfNLuPN3RYsdHN");

    return this.httpclient.get("https://api.tomorrow.io/v4/timelines?location=" + longitude + "," + langitude +"&fields=temperature&timesteps=1h&units=metric&apikey=7RhbiFjUeHIip62S8JTUV21KQIckjs0x");

  }

}
