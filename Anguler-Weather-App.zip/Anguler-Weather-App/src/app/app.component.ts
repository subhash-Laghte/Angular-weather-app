import { Component, OnInit } from '@angular/core';
import { ApptomorrowServiceService } from './services/apptomorrow-service.service';

export class apptomorrow {

  name: string
  temperature: string
  intervalslist:any

}

var weatherparam = [
  { id: 0, latitude: "34.296", longitude: "-80.113", cityName: "Lydia" },
  { id: 1, latitude: "43.142", longitude: "-93.287", cityName: "Fenwick" },
  { id: 2, latitude: "45.015", longitude: "-93.340", cityName: "Minneapolis" }
];

var diffLocations = [];
for (var citi of weatherparam) {
  let newName = {
    id: citi.id,
    latitude: citi.latitude,
    longitude: citi.longitude,
    cityN: citi.cityName
  };
  diffLocations.push(newName);
}

var newObj = function (object) {
  var newObject = {};
  for (var key in object) {
    if (object.hasOwnProperty(key)) {
      newObject[key] = object[key];
    }
  }
  return newObject;
};


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./appcomp.component.css']
})
export class AppComponent {

  //let longitude: any;
  //let  langitude: any;
  constructor(private apiservice: ApptomorrowServiceService) { }

  appTomm: apptomorrow = new apptomorrow()

  lstapptomorrow: Array<{ name: string, temperature: string, intervalslist:any }> = [];

  //lstapptomorrow = [];

ngOnInit() {

  for (let citi of weatherparam) {
    this.apiservice.getapitomorrow(citi.latitude, citi.longitude, citi.cityName)
      .subscribe(
        dataApp => {
          //this.lstapptomorrow = data;

          //this.appTomm.name = "Test";//['locations'][0]['name']

          //this.appTomm.name = dataApp['data']['locations'][0]['name']

          this.appTomm.temperature = dataApp['data']['timelines'][0]['intervals'][citi.id]['values']['temperature'];
          this.appTomm.name = citi.cityName;
          this.appTomm.intervalslist = dataApp['data']['timelines'][0]['intervals'];

          console.log("Array Length" + this.appTomm.intervalslist);

          this.lstapptomorrow.push({ name: this.appTomm.name, temperature: this.appTomm.temperature, intervalslist: this.appTomm.intervalslist });
       //   this.lstapptomorrow.push(Object.assign({}, { name: this.appTomm.name, temperature: this.appTomm.temperature }));
        }
      )

  }
}
}
